
public class SimpleConsoleOutputs {

}
