
public class SwapTwoStringsCorrect {

}
