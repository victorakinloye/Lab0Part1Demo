
public class SimpleInputUser2 {

}
