public class NumberVariables {



	public static void main(String[] args) {

		System.out.println("After intializing i's value to 5 ");

		

		int i=5;

		System.out.println("i's value is: " + i );

		

		i = 7;

		System.out.println("After changing i value to 7");

		System.out.println("i value is: " + i);

		

		double x = 23.5;

		double y = 24.7;

		System.out.println("Average between x and y is :" +((x+y)/2));

		System.out.println("Average between "+x+ "and" +y+ "is :" +((x+y)/2));

	}

	}
