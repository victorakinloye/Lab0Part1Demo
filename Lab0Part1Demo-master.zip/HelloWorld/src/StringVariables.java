
public class StringVariables {

}
