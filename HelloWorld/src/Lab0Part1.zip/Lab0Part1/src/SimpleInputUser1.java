
public class SimpleInputUser1 {

}
